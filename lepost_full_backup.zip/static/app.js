/* LePost — app.js (merged final)
   UI dari ui_baru, disambungkan ke api.py yang sudah lengkap.
   Perbaikan: /me, /public, /signup, /redeem, /admin/*, broadcast, grafik, undefined. */

const API = '/api';
const TABS = ['dashboard', 'posts', 'bypass', 'logs'];
const REFRESH_MS = 10000;

const state = {
  token: localStorage.getItem('token') || '',
  me: null,
  accounts: [],
  queries: [],
  logs: [],
  logFilter: 'ALL',
  logSearch: '',
  channels: { post: [], bypass: [] },
  reqId: { post: 0, bypass: 0, ch: 0 },
  bypassRef: '',
  isAutoAll: false,
  isBypassAll: false,
  sig: {},
  loaded: {},
  bgErr: {},
  openers: {},
  contact: null,
};

/* ───────── util ───────── */
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const chn = n => (n ? '#' + String(n).replace(/^#+/, '') : '');
const fixMsg = m => String(m ?? '').replace(/#{2,}/g, '#');
const sum = arr => arr.reduce((a, b) => a + b, 0);
const pad = n => String(n).padStart(2, '0');
const setText = (el, v) => {
  const node = typeof el === 'string' ? $(el) : el;
  if (node && node.textContent !== String(v)) node.textContent = v;
};
const changed = (key, value) => {
  const s = JSON.stringify(value);
  if (state.sig[key] === s) return false;
  state.sig[key] = s;
  return true;
};
const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]):not([type=hidden]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';

const PATHS = {
  play: '<path d="M8 5v14l11-7z" fill="currentColor" stroke="none"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor" stroke="none"/>',
  edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M5 6l1 14h12l1-14M10 11v6M14 11v6"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M21.5 20a6.5 6.5 0 0 0-4-6"/>',
  send: '<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  refresh: '<path d="M21 12a9 9 0 1 1-2.6-6.4L21 8"/><path d="M21 3v5h-5"/>',
};
const icon = (name, cls = '') =>
  `<svg class="ico ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${PATHS[name] || ''}</svg>`;

function shortTime(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  return isNaN(d) ? String(ts) : `${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function fullTime(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  return isNaN(d) ? String(ts) : d.toLocaleString('sv-SE');
}
function fmtDur(sec) {
  sec = Math.max(0, Math.floor(sec));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), x = sec % 60;
  if (h) return `${h}j ${m}m`;
  if (m) return `${m}m ${pad(x)}dtk`;
  return `${x}dtk`;
}
function dayLabel(date) {
  if (!date) return '-';
  const d = new Date(date + 'T00:00:00Z');
  return isNaN(d) ? '-' : d.toLocaleDateString('id-ID', { weekday: 'short', timeZone: 'UTC' });
}
function nextOf(q) {
  if (!q) return '';
  const bypass = q.query_type === 'bypass';
  const n = Math.max((q.bypass_data || []).length, 1);
  const gap = Math.max((q.delay_min * 60) / (bypass ? n : 1), 5) * 1000;
  const last = q.last_run ? new Date(q.last_run).getTime() : 0;
  return last ? last + gap : '';
}

/* ───────── skeleton / empty / error ───────── */
const skeleton = n =>
  `<div class="stack" role="status" aria-label="Memuat data">${Array.from({length:n},()=>'<div class="skel" aria-hidden="true"></div>').join('')}</div>`;
const errorBlock = (title, msg) =>
  `<div class="notice" role="alert"><div><p class="notice-title">${esc(title)}</p><p class="notice-msg">${esc(msg)}</p></div><button type="button" class="btn" data-act="refresh">${icon('refresh')}Coba lagi</button></div>`;
const emptyBlock = (title, text, act, label) =>
  `<div class="empty"><span class="empty-ic" aria-hidden="true">${icon('send')}</span><h3>${esc(title)}</h3><p>${esc(text)}</p>${act?`<button type="button" class="btn btn-primary" data-act="${act}">${icon('plus')}${esc(label)}</button>`:''}</div>`;
const inlineEmpty = (title, sub) =>
  `<div class="inline-empty"><p class="ie-title">${esc(title)}</p><p class="ie-sub">${esc(sub)}</p></div>`;

let toastTimer;
function toast(msg, isErr = false) {
  const t = $('toast');
  t.classList.toggle('err', isErr);
  $('toast-msg').textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 3500);
}
function reportBg(key, msg) {
  if (state.bgErr[key]) return;
  state.bgErr[key] = true;
  toast(msg, true);
}
const clearBg = key => { state.bgErr[key] = false; };

/* ───────── api ───────── */
async function api(path, opts = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (state.token) headers.Authorization = 'Bearer ' + state.token;
  let r;
  try {
    r = await fetch(API + path, { ...opts, headers });
  } catch {
    throw new Error('Tidak bisa terhubung ke server.');
  }
  if (r.status === 401 && path !== '/login') { logout(); throw new Error('Sesi habis, login lagi.'); }
  const txt = await r.text();
  let data = {};
  try { data = txt ? JSON.parse(txt) : {}; } catch { data = { raw: txt }; }
  if (!r.ok) {
    let msg = 'Terjadi kesalahan di server.';
    if (typeof data.detail === 'string') msg = data.detail;
    else if (Array.isArray(data.detail)) msg = data.detail.map(d => (d.loc ? d.loc.slice(1).join('.') + ': ' : '') + d.msg).join('; ');
    throw new Error(msg);
  }
  return data;
}

/* ───────── auth ───────── */
async function submitLogin(e) {
  e.preventDefault();
  const btn = $('login-btn'), err = $('login-err');
  err.hidden = true;
  btn.disabled = true; btn.textContent = 'Memproses...';
  try {
    const r = await api('/login', { method: 'POST', body: JSON.stringify({
      username: $('username').value.trim(), password: $('password').value,
    })});
    if (!r.token) throw new Error('Respons login tidak valid.');
    localStorage.setItem('token', r.token);
    location.reload();
  } catch (ex) {
    err.textContent = 'Login gagal: ' + ex.message;
    err.hidden = false;
    $('password').focus();
  } finally {
    btn.disabled = false; btn.textContent = 'Masuk';
  }
}

function setAuthTab(tab) {
  const login = tab === 'login';
  $('login-form').hidden = !login;
  $('signup-form').hidden = login;
  document.querySelectorAll('[data-auth]').forEach(b =>
    b.setAttribute('aria-pressed', String(b.dataset.auth === tab)));
}

async function submitSignup(e) {
  e.preventDefault();
  const btn = $('signup-btn'), err = $('signup-err');
  err.hidden = true;
  btn.disabled = true; btn.textContent = 'Memproses...';
  try {
    const r = await api('/signup', { method: 'POST', body: JSON.stringify({
      username: $('su-username').value.trim(),
      password: $('su-password').value,
      key: $('su-key').value.trim(),
    })});
    if (!r.token) throw new Error('Respons daftar tidak valid.');
    localStorage.setItem('token', r.token);
    location.reload();
  } catch (ex) {
    err.textContent = 'Daftar gagal: ' + ex.message;
    err.hidden = false;
  } finally {
    btn.disabled = false; btn.textContent = 'Daftar & Masuk';
  }
}

function contactHtml(c) {
  if (!c) return '<p class="hint">Kontak owner belum diatur.</p>';
  const items = [];
  if (c.wa) items.push(['WhatsApp', '+' + c.wa, `https://wa.me/${encodeURIComponent(c.wa)}`]);
  if (c.telegram) items.push(['Telegram', '@' + c.telegram, `https://t.me/${encodeURIComponent(c.telegram)}`]);
  if (c.discord) items.push(['Discord', c.discord, '']);
  if (!items.length) return '<p class="hint">Kontak owner belum diatur.</p>';
  return items.map(([n, v, href]) => href
    ? `<a class="contact-item" href="${esc(href)}" target="_blank" rel="noopener"><div><b>${n}</b><span>${esc(v)}</span></div></a>`
    : `<div class="contact-item"><div><b>${n}</b><span>${esc(v)}</span></div></div>`
  ).join('');
}

async function loadContact() {
  try {
    const c = await api('/public');
    state.contact = c;
    const box = $('contact-box');
    if (box) box.innerHTML = contactHtml(c);
  } catch {
    const box = $('contact-box');
    if (box) box.innerHTML = '<p class="hint">Kontak belum bisa dimuat.</p>';
  }
}

function logout() {
  state.token = '';
  localStorage.removeItem('token');
  location.reload();
}

/* ───────── lisensi ───────── */
function fmtLeft(sec) {
  if (sec == null) return 'Tanpa batas';
  if (sec <= 0) return 'Habis';
  const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600);
  return d > 0 ? `${d} hari ${h} jam` : `${h} jam ${Math.floor((sec % 3600) / 60)} menit`;
}
const lim = n => (n ? String(n) : '∞');

function renderMe() {
  const m = state.me; if (!m) return;
  const b = $('hdr-lic');
  if (m.is_admin) {
    if (b) b.hidden = true;
    const navAdmin = $('nav-admin');
    if (navAdmin) navAdmin.hidden = false;
    return;
  }
  if (!b) return;
  b.hidden = false;
  const soon = m.seconds_left != null && m.seconds_left < 3 * 86400;
  b.className = 'pill ' + (m.expired ? 'pill-off' : soon ? 'pill-warn' : 'pill-on');
  b.textContent = m.expired ? 'Masa aktif habis' : fmtLeft(m.seconds_left);
}

function openLicense(opener) {
  const m = state.me; if (!m) return;
  const row = (k, v) =>
    `<div class="acc-row"><div class="acc-text"><p class="acc-meta">${k}</p><p class="acc-name">${v}</p></div></div>`;
  $('lic-info').innerHTML = m.is_admin
    ? row('Akun', esc(m.username) + ' (admin)')
    : row('Akun', esc(m.username))
      + row('Sisa masa aktif', m.expired ? '<span style="color:#ffb4b4">Habis</span>' : esc(fmtLeft(m.seconds_left)))
      + row('Akun Discord', `${m.accounts} / ${lim(m.max_accounts)}`)
      + row('Channel', `${m.channels} / ${lim(m.max_channels)}`);
  $('lic-contact').innerHTML = state.contact
    ? '<h3 class="sub-h">Beli / perpanjang key</h3>' + contactHtml(state.contact)
    : '';
  openDialog('dlg-lic', opener);
}

async function submitRedeem(e) {
  e.preventDefault();
  const key = $('redeem-key').value.trim();
  if (!key) return toast('Key wajib diisi.', true);
  const btn = e.submitter || e.target.querySelector('[type=submit]');
  setBusy(btn, true);
  try {
    await api('/redeem', { method: 'POST', body: JSON.stringify({ key }) });
    toast('Key dipakai, masa aktif diperbarui.');
    setTimeout(() => location.reload(), 700);
  } catch (err) { toast(err.message, true); }
  finally { setBusy(btn, false); }
}

/* ───────── broadcast banner ───────── */
async function loadBroadcastBanner() {
  try {
    const bc = await api('/broadcast');
    if (!bc || !bc.message) return;
    // sisipkan banner di bawah header app
    const existing = document.getElementById('bc-banner');
    if (existing) existing.remove();
    const typeMap = { info: 'notice-info', warn: 'notice-warn', danger: 'notice-danger' };
    const cls = typeMap[bc.type] || 'notice-info';
    const banner = document.createElement('div');
    banner.id = 'bc-banner';
    banner.className = `notice ${cls}`;
    banner.setAttribute('role', 'alert');
    banner.style.cssText = 'margin:0 0 12px;border-radius:10px;';
    banner.innerHTML = `<div><p class="notice-title">${bc.type === 'danger' ? 'Penting' : bc.type === 'warn' ? 'Perhatian' : 'Info'}</p><p class="notice-msg">${esc(bc.message)}</p></div>`;
    const main = $('main');
    if (main) main.prepend(banner);
  } catch { /* broadcast optional, abaikan error */ }
}

/* ───────── panel admin ───────── */
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); }
  catch {
    const ta = document.createElement('textarea');
    ta.value = t; document.body.append(ta); ta.select();
    try { document.execCommand('copy'); } finally { ta.remove(); }
  }
  toast('Disalin.');
}

function setAdminTab(tab) {
  document.querySelectorAll('[data-atab]').forEach(b =>
    b.setAttribute('aria-pressed', String(b.dataset.atab === tab)));
  $('atab-keys').hidden = tab !== 'keys';
  $('atab-users').hidden = tab !== 'users';
  $('atab-stats').hidden = tab !== 'stats';
  $('atab-broadcast').hidden = tab !== 'broadcast';
  if (tab === 'users') loadAdminUsers();
  else if (tab === 'stats') loadAdminStats();
  else if (tab === 'broadcast') loadBroadcastCurrent();
  else loadAdminKeys();
}

function openAdmin(opener) { openDialog('dlg-admin', opener); setAdminTab('keys'); }

const fmtDate = iso => iso
  ? new Date(iso).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })
  : '-';

async function loadAdminStats() {
  const box = $('admin-stats-box');
  try {
    const [users, keys] = await Promise.all([api('/admin/users'), api('/admin/keys')]);
    const active  = users.filter(u => !u.expired && !u.is_admin);
    const expired = users.filter(u =>  u.expired && !u.is_admin);
    const usedKeys  = keys.filter(k => k.used_by);
    const availKeys = keys.filter(k => !k.used_by);
    box.innerHTML = `
      <div class="admin-stat-grid">
        <div class="admin-stat"><p class="admin-stat-n">${active.length}</p><p class="admin-stat-l">User Aktif</p></div>
        <div class="admin-stat"><p class="admin-stat-n">${expired.length}</p><p class="admin-stat-l">User Expired</p></div>
        <div class="admin-stat"><p class="admin-stat-n">${usedKeys.length}</p><p class="admin-stat-l">Key Terpakai</p></div>
        <div class="admin-stat"><p class="admin-stat-n">${availKeys.length}</p><p class="admin-stat-l">Key Tersedia</p></div>
      </div>
      <h3 class="sub-h" style="margin-top:16px">User aktif (masa aktif tersisa)</h3>
      ${active.length
        ? active
            .sort((a, b) => (a.seconds_left || 0) - (b.seconds_left || 0))
            .map(u => `
              <div class="acc-row col">
                <div class="row-top">
                  <p class="acc-name">${esc(u.username)}</p>
                  <span class="badge badge-ok">Aktif</span>
                </div>
                <p class="acc-meta">Sisa ${esc(fmtLeft(u.seconds_left))} · akun ${u.accounts}/${lim(u.max_accounts)} · ch ${u.channels}/${lim(u.max_channels)}</p>
                <div class="row-actions">
                  <button type="button" class="btn btn-sm btn-danger" data-act="admin-stop-user" data-id="${u.id}" data-name="${esc(u.username)}">Stop Query</button>
                </div>
              </div>`).join('')
        : '<p class="hint">Belum ada user aktif.</p>'}`;
  } catch (e) { box.innerHTML = `<p class="hint">${esc(e.message)}</p>`; }
}

async function adminStopUserQueries(id, name) {
  if (!(await ask('Stop semua query?', `Semua query milik "${name}" akan dihentikan paksa.`, 'Stop'))) return;
  try {
    await api(`/admin/users/${id}/stop`, { method: 'POST' });
    toast(`Query ${name} dihentikan.`);
    loadAdminStats();
  } catch (e) { toast(e.message, true); }
}

async function adminStopAll() {
  if (!(await ask('Stop semua query global?', 'Semua query dari semua user akan dihentikan paksa.', 'Stop Semua'))) return;
  try {
    await api('/admin/stop_all', { method: 'POST' });
    toast('Semua query dihentikan.');
  } catch (e) { toast(e.message, true); }
}

async function exportUsersCSV() {
  try {
    const users = await api('/admin/users');
    const rows = [['username','status','sisa_hari','max_accounts','max_channels','expires_at']];
    users.forEach(u => rows.push([
      u.username,
      u.is_admin ? 'admin' : u.expired ? 'expired' : 'aktif',
      u.seconds_left != null ? Math.floor(u.seconds_left / 86400) : '∞',
      u.max_accounts || '∞',
      u.max_channels || '∞',
      u.expires_at || '-',
    ]));
    const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = `lepost-users-${new Date().toISOString().slice(0,10)}.csv`;
    a.click(); URL.revokeObjectURL(a.href);
    toast('CSV diunduh.');
  } catch (e) { toast(e.message, true); }
}

async function submitBroadcast(e) {
  e.preventDefault();
  const msg = $('bc-msg').value.trim(), type = $('bc-type').value;
  if (!msg) return toast('Pesan wajib diisi.', true);
  const btn = e.submitter || e.target.querySelector('[type=submit]');
  setBusy(btn, true);
  try {
    await api('/admin/broadcast', { method: 'POST', body: JSON.stringify({ message: msg, type }) });
    toast('Broadcast dikirim.');
    $('bc-msg').value = '';
    loadBroadcastCurrent();
  } catch (e) { toast(e.message, true); }
  finally { setBusy(btn, false); }
}

async function loadBroadcastCurrent() {
  const box = $('bc-current');
  try {
    const r = await api('/admin/broadcast');
    if (!r || !r.message) {
      box.innerHTML = '<p class="hint">Tidak ada broadcast aktif.</p>';
      return;
    }
    box.innerHTML = `<div class="notice notice-${esc(r.type||'info')}"><div><p class="notice-title">Broadcast aktif</p><p class="notice-msg">${esc(r.message)}</p></div></div>`;
  } catch { box.innerHTML = '<p class="hint">Gagal memuat broadcast.</p>'; }
}

async function clearBroadcast() {
  try {
    await api('/admin/broadcast', { method: 'DELETE' });
    toast('Broadcast dihapus.');
    loadBroadcastCurrent();
  } catch (e) { toast(e.message, true); }
}

async function loadAdminKeys() {
  try {
    const list = await api('/admin/keys');
    $('key-list').innerHTML = list.length
      ? list.map(k => `
          <div class="acc-row col">
            <div class="row-top">
              <p class="acc-name key-code">${esc(k.key)}</p>
              <span class="badge ${k.used_by ? 'badge-bad' : 'badge-ok'}">${k.used_by ? 'Terpakai' : 'Tersedia'}</span>
            </div>
            <p class="acc-meta">${k.days} hari · akun ${lim(k.max_accounts)} · channel ${lim(k.max_channels)}${k.note ? ' · ' + esc(k.note) : ''}${k.used_by ? ' · oleh ' + esc(k.used_by) : ''}</p>
            <div class="row-actions">
              <button type="button" class="btn btn-sm" data-act="copy-key" data-key="${esc(k.key)}">Salin</button>
              ${k.used_by ? '' : `<button type="button" class="btn btn-sm btn-danger" data-act="del-key" data-id="${k.id}">Hapus</button>`}
            </div>
          </div>`).join('')
      : '<p class="hint">Belum ada key.</p>';
  } catch (e) { toast(e.message, true); }
}

async function submitKey(e) {
  e.preventDefault();
  const num = (id, d) => { const v = parseInt($(id).value, 10); return Number.isFinite(v) ? v : d; };
  const body = {
    days: num('key-days', 30), count: num('key-count', 1),
    max_accounts: num('key-acc', 1), max_channels: num('key-ch', 1),
    note: $('key-note').value.trim(),
  };
  const btn = e.submitter || e.target.querySelector('[type=submit]');
  setBusy(btn, true);
  try {
    const keys = await api('/admin/keys', { method: 'POST', body: JSON.stringify(body) });
    const box = $('key-new');
    box.hidden = false;
    box.innerHTML =
      `<p class="acc-meta">${keys.length} key dibuat:</p>`
      + keys.map(k => `<p class="key-code">${esc(k.key)}</p>`).join('')
      + `<button type="button" class="btn btn-sm" data-act="copy-key" data-key="${esc(keys.map(k=>k.key).join('\n'))}">Salin semua</button>`;
    loadAdminKeys();
  } catch (err) { toast(err.message, true); }
  finally { setBusy(btn, false); }
}

async function loadAdminUsers() {
  try {
    const list = await api('/admin/users');
    $('user-list').innerHTML = list.map(u => `
      <div class="acc-row col" data-uid="${u.id}">
        <div class="row-top">
          <p class="acc-name">${esc(u.username)}</p>
          <span class="badge ${u.is_admin ? 'badge-adm' : u.expired ? 'badge-bad' : 'badge-ok'}">${u.is_admin ? 'Admin' : u.expired ? 'Habis' : 'Aktif'}</span>
        </div>
        <p class="acc-meta">${u.is_admin ? 'Tanpa batas' : `Sisa ${esc(fmtLeft(u.seconds_left))} (s/d ${fmtDate(u.expires_at)})`} · akun ${u.accounts}/${lim(u.max_accounts)} · channel ${u.channels}/${lim(u.max_channels)}</p>
        ${u.is_admin ? '' : `
        <div class="two-col">
          <input class="input" data-f="days" type="number" inputmode="numeric" placeholder="+/- hari" aria-label="Tambah hari">
          <input class="input" data-f="pw" type="text" autocomplete="off" placeholder="Password baru" aria-label="Password baru">
          <input class="input" data-f="acc" type="number" min="0" inputmode="numeric" placeholder="Limit akun (${lim(u.max_accounts)})" aria-label="Limit akun">
          <input class="input" data-f="ch" type="number" min="0" inputmode="numeric" placeholder="Limit channel (${lim(u.max_channels)})" aria-label="Limit channel">
        </div>
        <div class="row-actions">
          <button type="button" class="btn btn-sm btn-primary" data-act="save-user" data-id="${u.id}">Simpan</button>
          <button type="button" class="btn btn-sm btn-danger" data-act="del-user" data-id="${u.id}" data-name="${esc(u.username)}">Hapus user</button>
        </div>`}
      </div>`).join('');
  } catch (e) { toast(e.message, true); }
}

async function saveUser(id, el) {
  const row = el.closest('[data-uid]');
  const v = f => row.querySelector(`[data-f="${f}"]`).value.trim();
  const body = {};
  if (v('days') !== '') body.add_days = parseInt(v('days'), 10);
  if (v('acc')  !== '') body.max_accounts = parseInt(v('acc'), 10);
  if (v('ch')   !== '') body.max_channels  = parseInt(v('ch'), 10);
  if (v('pw')   !== '') body.new_password  = v('pw');
  if (!Object.keys(body).length) return toast('Isi minimal satu kolom dulu.', true);
  setBusy(el, true);
  try {
    await api(`/admin/users/${id}`, { method: 'PATCH', body: JSON.stringify(body) });
    toast('User diperbarui.');
    loadAdminUsers();
  } catch (e) { toast(e.message, true); setBusy(el, false); }
}

async function delUser(id, name) {
  if (!(await ask('Hapus user?', `User "${name}" beserta akun & query-nya akan dihapus permanen.`, 'Hapus'))) return;
  try { await api(`/admin/users/${id}`, { method: 'DELETE' }); toast('User dihapus.'); loadAdminUsers(); }
  catch (e) { toast(e.message, true); }
}

async function delKey(id) {
  try { await api(`/admin/keys/${id}`, { method: 'DELETE' }); loadAdminKeys(); }
  catch (e) { toast(e.message, true); }
}

function initHeroCounters() {
  document.querySelectorAll('.hstat-n[data-target]').forEach(el => {
    const target = parseInt(el.dataset.target, 10);
    let start = null;
    const dur = 1400;
    function step(ts) {
      if (!start) start = ts;
      const p = Math.min((ts - start) / dur, 1);
      const ease = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(ease * target);
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  });
}

/* ───────── dialog ───────── */
function openDialog(id, opener) {
  const d = $(id); if (!d) return;
  state.openers[id] = opener || document.activeElement;
  d.hidden = false;
  document.body.classList.add('lock');
  (d.querySelector('[data-autofocus]') || d.querySelector(FOCUSABLE))?.focus();
}
function closeDialog(id) {
  const d = $(id); if (!d || d.hidden) return;
  d.hidden = true;
  if (!document.querySelector('.overlay:not([hidden])')) document.body.classList.remove('lock');
  if (id === 'dlg-post') resetPostForm();
  if (id === 'dlg-bypass') resetBypassForm();
  const back = state.openers[id];
  if (back && back.isConnected) back.focus();
}
function topOverlay() {
  const open = document.querySelectorAll('.overlay:not([hidden])');
  return open[open.length - 1] || null;
}
function trapFocus(e, root) {
  const f = [...root.querySelectorAll(FOCUSABLE)].filter(el => el.getClientRects().length);
  if (!f.length) return;
  const first = f[0], last = f[f.length - 1];
  if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
  else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
}
document.addEventListener('keydown', e => {
  const top = topOverlay(); if (!top) return;
  if (e.key === 'Escape') { e.preventDefault(); top._cancel ? top._cancel() : closeDialog(top.id); }
  if (e.key === 'Tab') trapFocus(e, top);
});
document.querySelectorAll('.overlay').forEach(o => {
  o.addEventListener('pointerdown', e => {
    if (e.target !== o) return;
    o._cancel ? o._cancel() : closeDialog(o.id);
  });
});

/* ───────── routing ───────── */
const currentRoute = () => {
  const h = location.hash.replace('#', '');
  return TABS.includes(h) ? h : 'dashboard';
};
function showTab(tab) {
  document.querySelectorAll('[data-view]').forEach(s => { s.hidden = s.dataset.view !== tab; });
  document.querySelectorAll('[data-tab]').forEach(a => {
    const on = a.dataset.tab === tab;
    a.classList.toggle('active', on);
    if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
  });
  loadStats();
  loadView(tab);
}
window.addEventListener('hashchange', () => { window.scrollTo(0, 0); showTab(currentRoute()); });

function loadView(tab) {
  if (tab === 'dashboard') return Promise.all([loadActivity(), loadDashQueries(), loadDashLogs()]);
  if (tab === 'logs') return loadLogs();
  return loadQueries();
}
function refreshNow() {
  loadStats();
  return loadView(currentRoute());
}
function refreshCurrent() {
  if (document.hidden || topOverlay() || !state.token) return;
  refreshNow();
}

/* ───────── dashboard ───────── */
function setHeader(on, n) {
  $('hdr-status').className = `pill ${on ? 'pill-on' : 'pill-off'}`;
  setText('hdr-status-t', on ? `${n} aktif` : 'Tidak aktif');
}
function setRing(rate) {
  const pct = rate == null ? 0 : Math.max(0, Math.min(100, rate));
  const fg = $('ring-fg');
  if (fg) fg.style.strokeDashoffset = String(188.5 * (1 - pct / 100));
  setText('ring-text', rate == null ? '-' : `${rate}%`);
  const ring = $('ring');
  if (!ring) return;
  ring.setAttribute('aria-label', rate == null ? 'Tingkat sukses, belum ada data' : `Tingkat sukses ${rate} persen`);
  ring.classList.remove('ring-good', 'ring-warn', 'ring-bad');
  if (rate != null) {
    if (pct >= 80) ring.classList.add('ring-good');
    else if (pct >= 50) ring.classList.add('ring-warn');
    else ring.classList.add('ring-bad');
  }
}

async function loadStats() {
  try {
    const s = await api('/stats');
    const on = (s.active || 0) > 0;
    setText('stat-total', s.total_posts ?? 0);
    setText('stat-sub-total', `+${s.posts_24h ?? 0} dalam 24 jam`);
    setText('stat-active', s.active ?? 0);
    setText('stat-sub-active', `dari ${s.scheduled ?? 0} query`);
    setText('stat-failed', s.failed ?? 0);
    setText('stat-sub-failed', s.success_rate == null ? 'Belum ada data' : `${100 - s.success_rate}% dari semua post`);
    setText('stat-accounts', state.accounts.length);
    setText('stat-sub-accounts', `${state.accounts.filter(a => a.proxy).length} pakai proxy`);
    const cardFailed = $('card-failed');
    if (cardFailed) cardFailed.classList.toggle('is-alert', (s.failed || 0) > 0);
    const cardActive = $('card-active');
    if (cardActive) cardActive.classList.toggle('is-live', on);
    const hero = $('hero');
    if (hero) hero.classList.toggle('is-live', on);
    setText('hero-date', new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long' }));
    setText('hero-title', on ? `${s.active} query sedang berjalan` : 'Semua query sedang berhenti');
    setText('hero-sub', on
      ? `${s.posts_24h ?? 0} post sukses dalam 24 jam terakhir`
      : (s.scheduled ? 'Buka Auto Post atau Bypass, lalu tekan Start.' : 'Belum ada query. Mulai dari Auto Post.'));
    const retryBtn = $('hero-retry');
    if (retryBtn) retryBtn.hidden = true;
    setRing(s.success_rate ?? null);
    setHeader(on, s.active ?? 0);
    clearBg('stats');
  } catch (e) {
    setText('hero-title', 'Data belum bisa dimuat');
    setText('hero-sub', e.message);
    const retryBtn = $('hero-retry');
    if (retryBtn) retryBtn.hidden = false;
    reportBg('stats', e.message);
  }
}

/* ───────── grafik aktivitas (canvas) ───────── */
function drawLineChart(canvas, rows) {
  if (!canvas) return;
  const dpr = window.devicePixelRatio || 1;
  const W = canvas.clientWidth || 320, H = canvas.clientHeight || 160;
  if (W === 0 || H === 0) return;
  canvas.width = Math.round(W * dpr);
  canvas.height = Math.round(H * dpr);
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.scale(dpr, dpr);
  const PAD = { top: 16, right: 16, bottom: 32, left: 36 };
  const cW = W - PAD.left - PAD.right;
  const cH = H - PAD.top  - PAD.bottom;
  if (cW <= 0 || cH <= 0) return;

  // pastikan rows valid
  const safeRows = Array.isArray(rows) ? rows : [];
  const okV  = safeRows.map(r => (r && typeof r.success === 'number') ? r.success : 0);
  const errV = safeRows.map(r => (r && typeof r.error   === 'number') ? r.error   : 0);
  const maxVal = Math.max(1, ...okV, ...errV);
  const labels = safeRows.map(r => dayLabel(r && r.date ? r.date : ''));
  const n = safeRows.length;
  if (n === 0) return;

  const xOf = i => PAD.left + (n < 2 ? cW / 2 : i * cW / (n - 1));
  const yOf = v => PAD.top + cH - (v / maxVal * cH);

  // grid lines
  ctx.strokeStyle = 'rgba(255,255,255,0.06)'; ctx.lineWidth = 1;
  [0, .25, .5, .75, 1].forEach(t => {
    const y = PAD.top + cH * (1 - t);
    ctx.beginPath(); ctx.moveTo(PAD.left, y); ctx.lineTo(PAD.left + cW, y); ctx.stroke();
  });

  // y-labels
  ctx.fillStyle = 'rgba(255,255,255,0.35)';
  ctx.font = '10px Inter,sans-serif'; ctx.textAlign = 'right';
  [0, .5, 1].forEach(t =>
    ctx.fillText(Math.round(maxVal * t), PAD.left - 6, PAD.top + cH * (1 - t) + 4));

  function drawLine(vals, color, fillColor) {
    if (!vals.some(v => v > 0)) return;
    ctx.beginPath();
    vals.forEach((v, i) => {
      const x = xOf(i), y = yOf(v);
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.strokeStyle = color; ctx.lineWidth = 2.5;
    ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.stroke();
    // area fill
    const grad = ctx.createLinearGradient(0, PAD.top, 0, PAD.top + cH);
    grad.addColorStop(0, fillColor); grad.addColorStop(1, 'transparent');
    ctx.lineTo(xOf(vals.length - 1), PAD.top + cH);
    ctx.lineTo(xOf(0), PAD.top + cH); ctx.closePath();
    ctx.fillStyle = grad; ctx.fill();
    // dots
    ctx.fillStyle = color;
    vals.forEach((v, i) => {
      if (v > 0) { ctx.beginPath(); ctx.arc(xOf(i), yOf(v), 3.5, 0, Math.PI * 2); ctx.fill(); }
    });
  }

  drawLine(errV, '#ff6b6b', 'rgba(255,107,107,0.15)');
  drawLine(okV,  '#4ade80', 'rgba(74,222,128,0.15)');

  // x-labels
  ctx.fillStyle = 'rgba(255,255,255,0.4)'; ctx.textAlign = 'center';
  labels.forEach((l, i) => ctx.fillText(l, xOf(i), H - 6));
}

let _chartAnim = null;
async function loadActivity() {
  const box = $('chart');
  if (!box) return;
  try {
    const rows = await api('/stats/activity?days=7');
    if (!changed('chart', rows)) return;
    const safeRows = Array.isArray(rows) ? rows : [];
    const ok  = sum(safeRows.map(r => r.success || 0));
    const bad = sum(safeRows.map(r => r.error   || 0));
    setText('chart-sum', ok + bad ? `${ok} sukses, ${bad} gagal dalam 7 hari` : 'Belum ada aktivitas');
    if (!ok && !bad) {
      box.innerHTML = '<p class="chart-empty">Belum ada aktivitas dalam 7 hari terakhir.</p>';
      return;
    }
    box.innerHTML = '<canvas id="chart-canvas" style="width:100%;height:160px;display:block"></canvas>';
    const canvas = $('chart-canvas');
    if (!canvas) return;
    let frame = 0; const totalFrames = 40;
    if (_chartAnim) cancelAnimationFrame(_chartAnim);
    function animate() {
      frame++;
      const ease = 1 - Math.pow(1 - Math.min(frame / totalFrames, 1), 3);
      drawLineChart(canvas, safeRows.map(r => ({
        date: r.date,
        success: Math.round((r.success || 0) * ease),
        error:   Math.round((r.error   || 0) * ease),
      })));
      if (ease < 1) _chartAnim = requestAnimationFrame(animate);
    }
    requestAnimationFrame(animate);
  } catch (e) {
    box.innerHTML = errorBlock('Grafik belum bisa dimuat.', e.message);
  }
}

async function fetchQueries() {
  const list = await api('/queries');
  state.queries = Array.isArray(list) ? list : [];
  return state.queries;
}

async function loadDashQueries() {
  const box = $('dash-running');
  if (!box) return;
  try {
    const list = await fetchQueries();
    const act = list.filter(q => q.status === 'active');
    if (!changed('run', act)) { tickCountdown(); return; }
    box.innerHTML = act.length
      ? act.map(q => {
          const bypass = q.query_type === 'bypass';
          return `<div class="run-item">
            <div class="run-top">
              <span class="run-name">${esc(chn(q.channel_name) || '#channel')}</span>
              <span class="tag ${bypass ? 'tag-bypass' : 'tag-auto'}">${bypass ? 'Bypass' : 'Auto'}</span>
            </div>
            <p class="cd js-count" data-active="1" data-next="${nextOf(q)}"></p>
          </div>`;
        }).join('')
      : inlineEmpty('Belum ada yang berjalan.', 'Tekan Start di Auto Post atau Bypass.');
    tickCountdown();
  } catch (e) {
    box.innerHTML = errorBlock('Status query belum bisa dimuat.', e.message);
  }
}

const logItem = l => {
  const err = l.level === 'ERROR', ok = l.level === 'SUCCESS';
  const cls = err ? 'lvl-err' : ok ? 'lvl-ok' : 'lvl-info';
  const label = err ? 'Error' : ok ? 'Sukses' : 'Info';
  return `<li>
    <time class="log-time" datetime="${esc(l.ts)}">${esc(shortTime(l.ts))}</time>
    <span class="lvl ${cls}">${label}</span>
    <p class="log-msg${err ? ' is-err' : ''}">${esc(fixMsg(l.message))}</p>
  </li>`;
};

async function loadDashLogs() {
  const box = $('dash-log-list');
  if (!box) return;
  try {
    const list = await api('/logs?limit=6');
    if (!changed('dlog', list)) return;
    box.innerHTML = list.length
      ? `<ul class="loglist">${list.map(logItem).join('')}</ul>`
      : inlineEmpty('Belum ada aktivitas.', 'Log akan muncul setelah query dijalankan.');
  } catch (e) {
    box.innerHTML = errorBlock('Log belum bisa dimuat.', e.message);
  }
}

function tickCountdown() {
  const now = Date.now();
  document.querySelectorAll('.js-count').forEach(el => {
    if (el.dataset.active === '0') {
      const last = el.dataset.last;
      setText(el, last ? `Terakhir jalan ${fmtDur((now - new Date(last)) / 1000)} lalu` : 'Belum pernah jalan');
      return;
    }
    const n = Number(el.dataset.next);
    if (!n) { setText(el, 'Menunggu post pertama'); return; }
    const diff = (n - now) / 1000;
    setText(el, diff > 0 ? `Post berikutnya dalam ${fmtDur(diff)}` : 'Sedang diproses');
  });
}

/* ───────── accounts ───────── */
function setSelect(sel, items, placeholder) {
  sel.innerHTML = '';
  sel.append(new Option(placeholder, ''));
  items.forEach(([v, t]) => sel.append(new Option(t, v)));
}

async function loadAccounts() {
  try {
    state.accounts = await api('/accounts');
    const sel = $('post-acc');
    const cur = sel ? sel.value : '';
    if (sel) {
      setSelect(sel, state.accounts.map(a => [a.id, `${a.label} (@${a.dc_user || '?'})`]), 'Pilih akun');
      if (cur) sel.value = cur;
    }
    renderBypassAccounts();
    clearBg('accounts');
  } catch (e) {
    reportBg('accounts', 'Akun belum bisa dimuat: ' + e.message);
  }
}

function renderAccountList() {
  const box = $('acc-list');
  if (!box) return;
  if (!state.accounts.length) {
    box.innerHTML = '<p class="hint">Belum ada akun. Tambahkan akun pertamamu di bawah.</p>';
    return;
  }
  box.innerHTML = state.accounts.map(a => `
    <div class="acc-row">
      <div class="acc-id">
        <span class="avatar" aria-hidden="true">${esc((a.label || '?').charAt(0).toUpperCase())}</span>
        <div class="acc-text">
          <p class="acc-name">${esc(a.label)}</p>
          <p class="acc-meta">@${esc(a.dc_user || '?')}${a.proxy ? ' · proxy' : ''}</p>
        </div>
      </div>
      <button type="button" class="btn btn-icon btn-danger" data-act="del-acc" data-id="${a.id}" aria-label="Hapus akun ${esc(a.label)}">${icon('trash')}</button>
    </div>`).join('');
}

function renderBypassAccounts() {
  const box = $('bypass-accounts');
  if (!box) return;
  if (!state.accounts.length) {
    box.innerHTML = '<p class="hint">Belum ada akun. Tambahkan dulu lewat menu Akun.</p>';
    return;
  }
  box.innerHTML = state.accounts.map(a => `
    <div class="pick">
      <label class="check">
        <input type="checkbox" class="bypass-check" value="${a.id}">
        <span>${esc(a.label)} <span class="muted">@${esc(a.dc_user || '?')}</span></span>
      </label>
      <textarea class="textarea bypass-text" rows="2" hidden aria-label="Pesan untuk ${esc(a.label)}" placeholder="Pesan untuk akun ini"></textarea>
    </div>`).join('');
}

async function hapusAkun(id) {
  const acc = state.accounts.find(a => a.id === id);
  if (!(await ask('Hapus akun ini?', `${acc ? acc.label : 'Akun'}. Query yang memakai akun ini bisa gagal jalan.`, 'Hapus'))) return;
  try {
    await api(`/accounts/${id}`, { method: 'DELETE' });
    await loadAccounts();
    renderAccountList();
    loadStats();
    toast('Akun dihapus.');
  } catch (e) { toast(e.message, true); }
}

function openAccounts(opener) {
  renderAccountList();
  openDialog('dlg-acc', opener);
}

async function submitAccount(e) {
  e.preventDefault();
  const label = $('acc-label').value.trim();
  const token = $('acc-token').value.trim();
  const proxy = $('acc-proxy').value.trim();
  if (!label || !token) return toast('Nama akun dan token wajib diisi.', true);
  const btn = e.submitter || e.target.querySelector('[type=submit]');
  setBusy(btn, true);
  try {
    await api('/accounts', { method: 'POST', body: JSON.stringify({ label, token, proxy }) });
    e.target.reset();
    await loadAccounts();
    renderAccountList();
    loadStats();
    toast('Akun ditambahkan.');
  } catch (err) { toast(err.message, true); }
  finally { setBusy(btn, false); }
}

/* ───────── channel ───────── */
function resetChannels(mode) {
  state.channels[mode] = [];
  const search = $(`${mode}-ch-search`);
  if (search) search.value = '';
  const chSel = $(`${mode}-channel`);
  if (chSel) { setSelect(chSel, [], 'Pilih server dulu'); chSel.disabled = true; }
}

async function loadGuilds(accId, mode, keepChannel = false) {
  const sel = $(`${mode}-guild`);
  if (!sel) return [];
  const req = ++state.reqId[mode];
  if (!keepChannel) resetChannels(mode);
  if (!accId) {
    setSelect(sel, [], 'Pilih akun dulu');
    sel.disabled = true;
    return [];
  }
  setSelect(sel, [], 'Memuat server...');
  sel.disabled = true;
  try {
    const guilds = await api(`/fetch/guilds/${accId}`);
    if (req !== state.reqId[mode]) return [];
    setSelect(sel, guilds.map(g => [g.id, g.name]), 'Pilih server');
    sel.disabled = false;
    return guilds;
  } catch (e) {
    if (req !== state.reqId[mode]) return [];
    setSelect(sel, [], 'Gagal memuat server');
    toast(e.message, true);
    return [];
  }
}

async function loadChannels(accId, gid, mode, keep = null) {
  const sel = $(`${mode}-channel`);
  if (!sel) return;
  const req = ++state.reqId.ch;
  state.channels[mode] = [];
  if (!gid || !accId) { resetChannels(mode); return; }
  setSelect(sel, [], 'Memuat channel...');
  sel.disabled = true;
  try {
    const chans = await api(`/fetch/channels/${accId}/${gid}`);
    if (req !== state.reqId.ch) return;
    if (keep && keep.id && !chans.some(c => c.id === keep.id)) {
      chans.unshift({ id: keep.id, name: String(keep.name).replace(/^#/, ''), slowmode: 0 });
    }
    state.channels[mode] = chans;
    const search = $(`${mode}-ch-search`);
    if (search) search.value = '';
    renderChannelOptions(mode, keep?.id);
    sel.disabled = false;
  } catch (e) {
    if (req !== state.reqId.ch) return;
    setSelect(sel, [], 'Gagal memuat channel');
    toast(e.message, true);
  }
}

function renderChannelOptions(mode, selectId) {
  const sel = $(`${mode}-channel`);
  if (!sel) return;
  const all = state.channels[mode];
  const current = selectId ?? sel.value;
  const searchEl = $(`${mode}-ch-search`);
  const kw = searchEl ? searchEl.value.trim().toLowerCase().replace(/^#/, '') : '';
  const list = all.filter(c => c.name.toLowerCase().includes(kw));
  const items = list.map(c => [c.id, chn(c.name)]);
  setSelect(sel, items, all.length ? (items.length ? 'Pilih channel' : 'Channel tidak ketemu') : 'Pilih server dulu');
  if (current && items.some(([v]) => v === current)) sel.value = current;
  sel.disabled = !all.length;
}

function channelOf(mode) {
  const sel = $(`${mode}-channel`);
  if (!sel) return { id: '', name: '' };
  const id = sel.value;
  const name = sel.options[sel.selectedIndex]?.text || '';
  return { id, name: id ? name : '' };
}

function onPickChannel(mode) {
  const id = $(`${mode}-channel`)?.value;
  const c = state.channels[mode].find(x => x.id === id);
  if (!c) return;
  const mins = c.slowmode > 0 ? Math.ceil(c.slowmode / 60) : 1;
  if (mode === 'post') {
    const pd = $('post-delay');
    if (pd) pd.value = mins;
  } else {
    const bts = $('bypass-total-slowmode');
    if (bts) { bts.value = mins; recalcBypassDelay(); }
  }
}

/* ───────── post dialog ───────── */
function resetPostForm() {
  const f = $('form-post'); if (f) f.reset();
  const pid = $('post-id'); if (pid) pid.value = '';
  const title = $('dlg-post-title'); if (title) title.textContent = 'Buat Post';
  const webhook = $('post-webhook-url');
  if (webhook) webhook.value = localStorage.getItem('lepost_webhook') || '';
  const guild = $('post-guild');
  if (guild) { setSelect(guild, [], 'Pilih akun dulu'); guild.disabled = true; }
  resetChannels('post');
}

function openPost(opener) {
  if (!state.accounts.length) return toast('Tambah akun dulu lewat menu Akun.', true);
  resetPostForm();
  const accSel = $('post-acc');
  if (accSel && state.accounts[0]) {
    accSel.value = state.accounts[0].id;
    loadGuilds(state.accounts[0].id, 'post');
  }
  openDialog('dlg-post', opener);
}

async function submitPost(e) {
  e.preventDefault();
  const id = $('post-id')?.value || '';
  const accId = Number($('post-acc')?.value || 0);
  const ch = channelOf('post');
  const content = $('post-content')?.value || '';
  const delay = Math.ceil(Number($('post-delay')?.value || 5));
  if (!accId) return toast('Pilih akun dulu.', true);
  if (!ch.id) return toast('Pilih server dan channel dulu.', true);
  if (!content.trim()) return toast('Isi pesan dulu.', true);
  if (!(delay >= 1)) return toast('Delay minimal 1 menit.', true);
  const webhook = $('post-webhook-url')?.value.trim() || '';
  if (webhook) localStorage.setItem('lepost_webhook', webhook);
  const payload = {
    query_type: 'auto',
    bypass_data: [{ account_id: accId, content }],
    guild_id: $('post-guild')?.value || '',
    channel_id: ch.id, channel_name: ch.name,
    content, webhook_url: webhook, delay_min: delay,
  };
  await saveQuery(e.target, id, payload, 'Post disimpan.', 'dlg-post');
}

/* ───────── bypass dialog ───────── */
const firstChecked = () => document.querySelector('.bypass-check:checked')?.value || '';

function recalcBypassDelay() {
  const totalEl = $('bypass-total-slowmode');
  const total = Math.max(1, parseInt(totalEl?.value || '1', 10) || 1);
  const n = document.querySelectorAll('.bypass-check:checked').length;
  const delayEl = $('bypass-delay');
  if (delayEl) delayEl.value = n > 0 ? Math.ceil(total / n) : total;
  setText('bypass-count', `${n} akun dipilih`);
}

function syncBypassRef() {
  const ref = firstChecked();
  if (ref === state.bypassRef) return;
  state.bypassRef = ref;
  if (ref) loadGuilds(ref, 'bypass');
  else {
    const bg = $('bypass-guild');
    if (bg) { setSelect(bg, [], 'Pilih akun dulu'); bg.disabled = true; }
    resetChannels('bypass');
  }
}

function onBypassPick(e) {
  const cb = e.target;
  if (!cb.matches('.bypass-check')) return;
  const pick = cb.closest('.pick');
  pick.classList.toggle('is-on', cb.checked);
  pick.querySelector('.bypass-text').hidden = !cb.checked;
  recalcBypassDelay();
  syncBypassRef();
}

function selectAllBypass() {
  document.querySelectorAll('.bypass-check').forEach(cb => {
    cb.checked = true;
    const pick = cb.closest('.pick');
    pick.classList.add('is-on');
    pick.querySelector('.bypass-text').hidden = false;
  });
  recalcBypassDelay();
  syncBypassRef();
}

function resetBypassForm() {
  const f = $('form-bypass'); if (f) f.reset();
  const bid = $('bypass-id'); if (bid) bid.value = '';
  const title = $('dlg-bypass-title'); if (title) title.textContent = 'Buat Bypass';
  document.querySelectorAll('.pick').forEach(p => {
    p.classList.remove('is-on');
    p.querySelector('.bypass-text').hidden = true;
  });
  state.bypassRef = '';
  const bg = $('bypass-guild');
  if (bg) { setSelect(bg, [], 'Pilih akun dulu'); bg.disabled = true; }
  resetChannels('bypass');
  recalcBypassDelay();
}

function openBypass(opener) {
  if (state.accounts.length < 2) return toast('Bypass butuh minimal 2 akun.', true);
  resetBypassForm();
  openDialog('dlg-bypass', opener);
}

async function submitBypass(e) {
  e.preventDefault();
  const id = $('bypass-id')?.value || '';
  const data = [...document.querySelectorAll('.bypass-check:checked')].map(c => ({
    account_id: Number(c.value),
    content: c.closest('.pick').querySelector('.bypass-text').value,
  }));
  const ch = channelOf('bypass');
  if (data.length < 2) return toast('Pilih minimal 2 akun.', true);
  if (data.some(d => !d.content.trim())) return toast('Isi pesan untuk setiap akun yang dipilih.', true);
  if (!ch.id) return toast('Pilih server dan channel dulu.', true);
  const payload = {
    query_type: 'bypass', bypass_data: data,
    guild_id: $('bypass-guild')?.value || '',
    channel_id: ch.id, channel_name: ch.name,
    delay_min: Math.max(1, Math.ceil(parseFloat($('bypass-total-slowmode')?.value || '120') || 120)),
  };
  await saveQuery(e.target, id, payload, 'Bypass disimpan.', 'dlg-bypass');
}

async function saveQuery(form, id, payload, okMsg, dialogId) {
  const btn = form.querySelector('[type=submit]');
  setBusy(btn, true);
  try {
    const body = JSON.stringify(payload);
    if (id) await api(`/queries/${id}`, { method: 'PATCH', body });
    else await api('/queries', { method: 'POST', body });
    toast(okMsg);
    closeDialog(dialogId);
    refreshNow();
  } catch (err) { toast(err.message, true); }
  finally { setBusy(btn, false); }
}

function setBusy(el, busy) {
  if (!el) return;
  el.disabled = busy;
  el.setAttribute('aria-busy', busy ? 'true' : 'false');
}

/* ───────── edit query ───────── */
async function editQ(id) {
  const q = state.queries.find(x => x.id === id);
  if (!q) return toast('Query tidak ditemukan, muat ulang daftar.', true);
  const keep = { id: q.channel_id, name: q.channel_name || q.channel_id };
  const opener = document.activeElement;

  if (q.query_type === 'auto') {
    resetPostForm();
    const accId = q.bypass_data?.[0]?.account_id || '';
    const title = $('dlg-post-title'); if (title) title.textContent = 'Edit Post';
    const pid = $('post-id'); if (pid) pid.value = q.id;
    const pacc = $('post-acc'); if (pacc) pacc.value = accId;
    const pc = $('post-content'); if (pc) pc.value = q.content || q.bypass_data?.[0]?.content || '';
    const pd = $('post-delay'); if (pd) pd.value = q.delay_min;
    const pw = $('post-webhook-url'); if (pw) pw.value = q.webhook_url || '';
    openDialog('dlg-post', opener);
    const guilds = await loadGuilds(accId, 'post', true);
    if (q.guild_id && guilds.some(g => g.id === q.guild_id)) {
      const pg = $('post-guild'); if (pg) pg.value = q.guild_id;
      await loadChannels(accId, q.guild_id, 'post', keep);
    }
  } else {
    resetBypassForm();
    const title = $('dlg-bypass-title'); if (title) title.textContent = 'Edit Bypass';
    const bid = $('bypass-id'); if (bid) bid.value = q.id;
    const bts = $('bypass-total-slowmode'); if (bts) bts.value = q.delay_min;
    (q.bypass_data || []).forEach(d => {
      const cb = document.querySelector(`.bypass-check[value="${d.account_id}"]`);
      if (!cb) return;
      cb.checked = true;
      const pick = cb.closest('.pick');
      pick.classList.add('is-on');
      const t = pick.querySelector('.bypass-text');
      t.hidden = false; t.value = d.content;
    });
    recalcBypassDelay();
    openDialog('dlg-bypass', opener);
    state.bypassRef = firstChecked();
    if (!state.bypassRef) return;
    const guilds = await loadGuilds(state.bypassRef, 'bypass', true);
    if (q.guild_id && guilds.some(g => g.id === q.guild_id)) {
      const bg = $('bypass-guild'); if (bg) bg.value = q.guild_id;
      await loadChannels(state.bypassRef, q.guild_id, 'bypass', keep);
    }
  }
}

/* ───────── query list ───────── */
const countLabel = arr =>
  arr.length ? `${arr.length} query, ${arr.filter(q => q.status === 'active').length} berjalan` : 'Belum ada query';

function toggleBtn(id, on) {
  const b = $(id); if (!b) return;
  b.innerHTML = on ? `${icon('stop')}Stop semua` : `${icon('play')}Start semua`;
  b.className = `btn ${on ? 'btn-stop' : 'btn-start'}`;
}

const msgBlock = text => {
  const t = String(text ?? '');
  if (t.length > 140) {
    return `<details class="more"><summary>Lihat pesan (${t.length} karakter)</summary><p class="msg msg-full">${esc(t)}</p></details>`;
  }
  return `<p class="msg msg-short">${esc(t)}</p>`;
};

function cardHtml(q, n) {
  const bypass = q.query_type === 'bypass';
  const on = q.status === 'active';
  const accs = Array.isArray(q.bypass_data) ? q.bypass_data : [];
  const cnt = accs.length;
  const per = bypass && cnt ? ` · ${Math.ceil(q.delay_min / cnt)}m/akun` : '';
  const title = esc(chn(q.channel_name) || '#channel');
  let body;
  if (bypass) {
    body = `<ul class="acc-msgs">${accs.map(d => {
      const a = state.accounts.find(x => x.id === d.account_id);
      return `<li class="acc-line"><span class="chip"><span>${esc(a ? a.label : 'Akun tidak dikenal')}</span></span>${msgBlock(d.content)}</li>`;
    }).join('')}</ul>`;
  } else {
    body = msgBlock(q.content);
  }
  let accChip;
  if (bypass) accChip = `${icon('users')}<span>${cnt} akun</span>`;
  else {
    const a = state.accounts.find(x => x.id === accs[0]?.account_id);
    accChip = `${icon('users')}<span>${esc(a ? a.label : 'Akun ?')}</span>`;
  }
  return `<article class="qcard${on ? ' is-on' : ''}">
    <div class="qhead">
      <h3 class="qtitle">${title}</h3>
      <span class="pill ${on ? 'pill-on' : 'pill-off'}">${on ? 'Berjalan' : 'Berhenti'}</span>
    </div>
    ${body}
    <div class="meta">
      <span class="chip ${bypass ? 'chip-bypass' : 'chip-auto'}">${bypass ? 'Bypass' : 'Auto'} #${n}</span>
      <span class="chip">${icon('clock')}<span>${q.delay_min}m${per}</span></span>
      <span class="chip">${accChip}</span>
    </div>
    <p class="cd js-count" data-active="${on ? 1 : 0}" data-next="${on ? nextOf(q) : ''}" data-last="${esc(q.last_run || '')}"></p>
    <div class="qfoot">
      <button type="button" class="btn ${on ? 'btn-stop' : 'btn-start'}" data-act="toggle" data-id="${q.id}" data-status="${esc(q.status)}">${icon(on ? 'stop' : 'play')}<span>${on ? 'Stop' : 'Start'}</span></button>
      <button type="button" class="btn" data-act="edit" data-id="${q.id}">${icon('edit')}<span>Edit</span></button>
      <button type="button" class="btn" data-act="clone" data-id="${q.id}">${icon('copy')}<span>Clone</span></button>
      <button type="button" class="btn btn-danger" data-act="delete" data-id="${q.id}">${icon('trash')}<span>Hapus</span></button>
    </div>
  </article>`;
}

function renderQueries(list) {
  const auto   = list.filter(q => q.query_type === 'auto');
  const bypass = list.filter(q => q.query_type === 'bypass');
  const num = {};
  auto.forEach((q, i)   => { num[q.id] = i + 1; });
  bypass.forEach((q, i) => { num[q.id] = i + 1; });
  state.isAutoAll   = auto.length   > 0 && auto.every(q   => q.status === 'active');
  state.isBypassAll = bypass.length > 0 && bypass.every(q => q.status === 'active');
  setText('count-auto',   countLabel(auto));
  setText('count-bypass', countLabel(bypass));
  toggleBtn('btn-toggle-auto',   state.isAutoAll);
  toggleBtn('btn-toggle-bypass', state.isBypassAll);
  const autoBox = $('q-list-auto');
  if (autoBox) autoBox.innerHTML = auto.length
    ? auto.map(q => cardHtml(q, num[q.id])).join('')
    : emptyBlock('Belum ada Auto Post', 'Buat post otomatis pertama. Pesan dikirim berkala ke channel yang kamu pilih.', 'new-post', '+ Tambah Post');
  const bypassBox = $('q-list-bypass');
  if (bypassBox) bypassBox.innerHTML = bypass.length
    ? bypass.map(q => cardHtml(q, num[q.id])).join('')
    : emptyBlock('Belum ada Bypass', 'Gabungkan minimal dua akun untuk posting bergiliran di satu channel.', 'new-bypass', '+ Tambah Bypass');
}

async function loadQueries() {
  const boxes = [$('q-list-auto'), $('q-list-bypass')];
  if (!state.loaded.queries) boxes.forEach(b => { if (b) b.innerHTML = skeleton(2); });
  try {
    const list = await fetchQueries();
    state.loaded.queries = true;
    clearBg('queries');
    if (changed('queries', [list, state.accounts])) renderQueries(list);
    tickCountdown();
  } catch (e) {
    if (state.loaded.queries) return reportBg('queries', e.message);
    boxes.forEach(b => { if (b) b.innerHTML = errorBlock('Daftar query belum bisa dimuat.', e.message); });
  }
}

async function toggleQ(id, status, btn) {
  const isActive = status === 'active';
  if (!isActive) {
    const q = state.queries.find(x => x.id === id);
    if (!(await ask('Start query ini?', chn(q?.channel_name), 'Start', false))) return;
  }
  setBusy(btn, true);
  try {
    await api(`/queries/${id}`, { method: 'PATCH', body: JSON.stringify({ status: isActive ? 'stopped' : 'active' }) });
    toast(isActive ? 'Query dihentikan.' : 'Query dijalankan.');
    refreshNow();
  } catch (e) { toast(e.message, true); setBusy(btn, false); }
}

async function delQ(id) {
  const q = state.queries.find(x => x.id === id);
  if (!(await ask('Hapus query ini?', chn(q?.channel_name), 'Hapus'))) return;
  try { await api(`/queries/${id}`, { method: 'DELETE' }); toast('Query dihapus.'); refreshNow(); }
  catch (e) { toast(e.message, true); }
}

async function toggleAll(type) {
  try {
    const list = await fetchQueries();
    const targets = list.filter(q => q.query_type === type);
    if (!targets.length) return toast('Belum ada query di daftar ini.', true);
    const wasOn = type === 'auto' ? state.isAutoAll : state.isBypassAll;
    const next  = wasOn ? 'stopped' : 'active';
    const label = type === 'auto' ? 'Auto Post' : 'Bypass';
    if (!(await ask(
      `${wasOn ? 'Stop' : 'Start'} semua ${label}?`,
      `${targets.length} query akan ${wasOn ? 'dihentikan' : 'dijalankan'}.`,
      wasOn ? 'Stop' : 'Start', wasOn))) return;
    const results = await Promise.allSettled(
      targets.filter(q => q.status !== next)
        .map(q => api(`/queries/${q.id}`, { method: 'PATCH', body: JSON.stringify({ status: next }) }))
    );
    const failed = results.filter(r => r.status === 'rejected').length;
    if (failed) toast(`${failed} query gagal di${next === 'active' ? 'jalankan' : 'hentikan'}.`, true);
    else toast(`Semua ${label} ${next === 'active' ? 'dijalankan' : 'dihentikan'}.`);
    refreshNow();
  } catch (e) { toast(e.message, true); }
}

async function cloneQ(id) {
  const q = state.queries.find(x => x.id === id);
  if (!q) return toast('Query tidak ditemukan, muat ulang daftar.', true);
  const p = {
    query_type: q.query_type, bypass_data: q.bypass_data || [],
    guild_id: q.guild_id || '', channel_id: q.channel_id,
    channel_name: q.channel_name, delay_min: q.delay_min, status: 'stopped',
  };
  if (q.content) p.content = q.content;
  if (q.webhook_url) p.webhook_url = q.webhook_url;
  try {
    await api('/queries', { method: 'POST', body: JSON.stringify(p) });
    toast('Query di-clone, status berhenti.');
    refreshNow();
  } catch (e) { toast(e.message, true); }
}

/* ───────── confirm dialog ───────── */
function ask(title, msg, okLabel = 'OK', danger = true) {
  return new Promise(resolve => {
    const d = $('dlg-confirm');
    $('confirm-title').textContent = title;
    $('confirm-msg').textContent = msg || '';
    const ok = $('confirm-ok');
    ok.textContent = okLabel;
    ok.className = `btn ${danger ? 'btn-stop' : 'btn-start'}`;
    const done = v => {
      d._cancel = null; ok.onclick = null;
      closeDialog('dlg-confirm'); resolve(v);
    };
    ok.onclick = () => done(true);
    $('confirm-no').onclick = () => done(false);
    d._cancel = () => done(false);
    openDialog('dlg-confirm', document.activeElement);
  });
}

/* ───────── logs ───────── */
function renderLogs() {
  const box = $('log-body');
  if (!box) return;
  const kw = state.logSearch.trim().toLowerCase();
  const rows = state.logs.filter(l =>
    (state.logFilter === 'ALL' || l.level === state.logFilter) &&
    (!kw || fixMsg(l.message).toLowerCase().includes(kw)));
  setText('log-count', `${rows.length} dari ${state.logs.length} log`);
  if (!rows.length) {
    box.innerHTML = state.logs.length
      ? emptyBlock('Tidak ada log yang cocok.', 'Coba ubah filter atau kata kunci.')
      : emptyBlock('Belum ada log.', 'Log akan muncul saat query berjalan.');
    return;
  }
  box.innerHTML = `<ul class="loglist">${rows.map(logItem).join('')}</ul>`;
}

async function loadLogs() {
  const box = $('log-body');
  if (!state.loaded.logs && box) box.innerHTML = skeleton(1);
  try {
    const list = await api('/logs?limit=200');
    state.loaded.logs = true;
    clearBg('logs');
    if (changed('logs', list)) { state.logs = list; renderLogs(); }
  } catch (e) {
    if (state.loaded.logs) return reportBg('logs', e.message);
    if (box) box.innerHTML = errorBlock('Log belum bisa dimuat.', e.message);
  }
}

function exportLogs() {
  if (!state.logs.length) return toast('Belum ada log untuk diunduh.', true);
  const q = s => '"' + String(s ?? '').replace(/"/g, '""') + '"';
  const csv = ['time,level,message',
    ...state.logs.map(l => [fullTime(l.ts), l.level, fixMsg(l.message)].map(q).join(','))
  ].join('\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
  a.download = 'lepost-logs.csv';
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

/* ───────── event delegation ───────── */
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (!el || el.disabled) return;
  const id = Number(el.dataset.id);
  switch (el.dataset.act) {
    case 'logout':           return logout();
    case 'open-admin':       return openAdmin(el);
    case 'open-lic':         return openLicense(el);
    case 'copy-key':         return copyText(el.dataset.key);
    case 'del-key':          return delKey(id);
    case 'save-user':        return saveUser(id, el);
    case 'del-user':         return delUser(id, el.dataset.name);
    case 'refresh':          return refreshNow();
    case 'toggle':           return toggleQ(id, el.dataset.status, el);
    case 'edit':             return editQ(id);
    case 'clone':            return cloneQ(id);
    case 'delete':           return delQ(id);
    case 'toggle-all':       return toggleAll(el.dataset.type);
    case 'new-post':         return openPost(el);
    case 'new-bypass':       return openBypass(el);
    case 'open-acc':         return openAccounts(el);
    case 'del-acc':          return hapusAkun(id);
    case 'select-all':       return selectAllBypass();
    case 'export-csv':       return exportLogs();
    case 'close':            return closeDialog(el.dataset.dialog);
    case 'admin-stop-user':  return adminStopUserQueries(id, el.dataset.name);
    case 'admin-stop-all':   return adminStopAll();
    case 'export-users-csv': return exportUsersCSV();
    case 'clear-broadcast':  return clearBroadcast();
  }
});

/* ───────── wiring form & nav ───────── */
$('login-form')?.addEventListener('submit', submitLogin);
$('signup-form')?.addEventListener('submit', submitSignup);
$('form-key')?.addEventListener('submit', submitKey);
$('form-redeem')?.addEventListener('submit', submitRedeem);
$('form-broadcast')?.addEventListener('submit', submitBroadcast);
document.querySelectorAll('[data-auth]').forEach(b =>
  b.addEventListener('click', () => setAuthTab(b.dataset.auth)));
document.querySelectorAll('[data-atab]').forEach(b =>
  b.addEventListener('click', () => setAdminTab(b.dataset.atab)));
$('form-post')?.addEventListener('submit', submitPost);
$('form-bypass')?.addEventListener('submit', submitBypass);
$('form-acc')?.addEventListener('submit', submitAccount);
$('post-acc')?.addEventListener('change', e => loadGuilds(e.target.value, 'post'));
$('post-guild')?.addEventListener('change', e => loadChannels($('post-acc').value, e.target.value, 'post'));
$('bypass-guild')?.addEventListener('change', e => loadChannels(state.bypassRef, e.target.value, 'bypass'));
$('bypass-accounts')?.addEventListener('change', onBypassPick);
$('bypass-total-slowmode')?.addEventListener('input', recalcBypassDelay);
['post', 'bypass'].forEach(mode => {
  $(`${mode}-ch-search`)?.addEventListener('input', () => renderChannelOptions(mode));
  $(`${mode}-channel`)?.addEventListener('change', () => onPickChannel(mode));
});
$('log-seg')?.addEventListener('click', e => {
  const b = e.target.closest('button[data-l]');
  if (!b) return;
  state.logFilter = b.dataset.l;
  document.querySelectorAll('#log-seg button').forEach(x =>
    x.setAttribute('aria-pressed', String(x === b)));
  renderLogs();
});
$('log-q')?.addEventListener('input', e => { state.logSearch = e.target.value; renderLogs(); });

/* ───────── boot ───────── */
async function boot() {
  loadContact();
  if (!state.token) {
    const vl = $('view-login');
    if (vl) vl.hidden = false;
    initHeroCounters();
    return;
  }
  const app = $('app');
  if (app) app.hidden = false;
  if (!TABS.includes(location.hash.replace('#', ''))) history.replaceState(null, '', '#dashboard');
  try { state.me = await api('/me'); } catch { return; }
  renderMe();
  if (state.me && state.me.expired) {
    const main = $('main');
    if (main) main.innerHTML =
      '<div class="notice exp-banner"><p class="notice-title">Masa aktif habis</p>' +
      '<p class="notice-msg">Masukkan key baru atau hubungi owner buat perpanjang.</p>' +
      '<button type="button" class="btn btn-primary" data-act="open-lic" style="margin-top:10px">Perpanjang sekarang</button></div>';
    openLicense();
    return;
  }
  await loadAccounts();
  showTab(currentRoute());
  loadBroadcastBanner();
  setInterval(refreshCurrent, REFRESH_MS);
  setInterval(tickCountdown, 1000);
  setInterval(() => api('/me').then(m => { state.me = m; renderMe(); }).catch(() => {}), 60000);
}
boot();
